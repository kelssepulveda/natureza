class Guardado:
    def __init__(self, request):
        self.request = request
        self.session = request.session 
        guardado=self.session.get("guardado")
        if not guardado:
            guardado=self.session["guardado"]={}
        self.guardado=guardado

    def agregar(self, producto):
        if(str(producto.id) not in self.guardado.keys()):
            self.guardado[producto.id]={
                "producto_id" : producto.id,
                "nombre" : producto.nombre,
                "precio" : producto.precio,
                "cantidad" : 1,
                "imagen" : producto.imagen.url
            }
        else:
           for key, value in self.guardado.items():
               if key==str(producto.id):
                   value["cantidad"]=value["cantidad"]+1
                   value["precio"]=value["precio"]+producto.precio
                   break
        self.guardar_producto()
    
    def guardar_producto(self):
        self.session["guardado"]=self.guardado
        self.session.modified=True

    def eliminar(self, producto):
        producto.id=str(producto.id)
        if producto.id in self.guardado:
            del self.guardado[producto.id]
            self.guardar_producto()

    def restar(self, producto):
        for key, value in self.guardado.items():
            if key==str(producto.id):
                value["cantidad"]=value["cantidad"]-1
                value["precio"]=value["precio"]-producto.precio
                if value["cantidad"]<1:
                    self.eliminar(producto)
                break
        self.guardar_producto()

    def limpiar_producto(self):
        self.session["guardado"]={}
        self.session.modified=True
